import { Link } from "expo-router";
import { Text, View } from "react-native";
import { styles } from "../../styles/autn.styles";


export default function Index() {
  return (    
    // <View
    //   style={styles.container}
    // >
    //   <Text style={styles.title}>Home Screen</Text>
    //   <Text>Edit app/index.tsx to edit this screen.</Text>
    //   <Text>-------</Text>
    //   <Text style={styles.title}>React Native </Text>   
    //   <TouchableOpacity onPress={()=>alert('You Touched | TouchableOpacity')}>
    //     <Text>Press ME | TouchableOpacity</Text>
    //   </TouchableOpacity>
    //   <Pressable onPress={()=>alert('You Touched | Pressable')}>
    //     <Text>Press ME | Pressable</Text>
    //   </Pressable>

    //   {/* <Image source={require('../assets/images/react-logo.png')} /> */}
    //   {/* <Image source={require('../assets/images/react-logo.png')} /> */}
    //   <Image style={styles.imageStyle } source={{uri:"https://images.unsplash.com/photo-1467385829985-2b0fb82b5193?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTV8fG91dGRvb3J8ZW58MHx8MHx8fDA%3D"}}/>
    //   <Text> ---------------  </Text>

    //   <Link href={"/notifications"}>Click here, to Visit Notifiaction Screen</Link>
      
    // </View>
    <View>
        <Text style={styles.title}>Home Screen</Text>
        
        <View style={styles.container}>
         <Link href={"/notifications"}>Click here, to Visit Notifiaction Screen</Link>
        </View>
    </View>
  );
}

1