import { styles } from '@/styles/autn.styles'
import React from 'react'
import { Text, View } from 'react-native'

export default function Create() {
  return (
    <View>
      <Text style={styles.title}>Create Screen</Text>
    </View>
  )
}