import { styles } from '@/styles/autn.styles'
import React from 'react'
import { Text, View } from 'react-native'

export default function bookmarks() {
  return (
    <View>
      <Text style={styles.title}>Bookmarks Screen</Text>
    </View>
  )
}