import { styles } from '@/styles/autn.styles'
import React from 'react'
import { Text, View } from 'react-native'

export default function Notifications() {
  return (
    <View>
      <Text style={styles.title}>Notifications Screen</Text>
    </View>
  )
}