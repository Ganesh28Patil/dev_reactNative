import React from 'react'
import { Text, View } from 'react-native'

const Saved = () => {
  return (
    <View>
      <Text>Saved</Text>
    </View>
  )
}

export default Saved